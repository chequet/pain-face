This is a demo of a shallow Neural Network trained on all subjects except subject 1, 
and tested on 200 images from subject 1. 

To run, simply enter 'python demo.py' in the command line. 
You will need joblib and sklearn installed. 

https://github.com/chequet/pain-face
