import joblib
import warnings
warnings.filterwarnings("ignore", message="numpy.dtype size changed")
warnings.filterwarnings("ignore", message="numpy.ufunc size changed")
from sklearn.metrics import classification_report

test = joblib.load('pca.pkl')
clf = joblib.load('clf.pkl')
labels = joblib.load('labels.pkl')

print('...testing...')
pred = clf.predict(test)
print('RESULT')
class_names = ['no pain', 'pain']
print(classification_report(labels,pred, target_names=class_names))
